﻿using Microsoft.AspNetCore.Mvc;
using Usermanagement1.Controllers.Data;
using Usermanagement1.Models;

namespace Usermanagement1.Controllers
{
    public class UserController : Controller
    {
        private readonly UserDbContext userDbcontext;
        public UserController(UserDbContext db)
        {
            userDbcontext = db;
        }

        public IActionResult Index()
        {
            IEnumerable<User> user = userDbcontext.user;
            return View(user);
        }
    }
}

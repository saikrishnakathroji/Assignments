﻿using Microsoft.EntityFrameworkCore;
using Usermanagement1.Models;

namespace Usermanagement1.Controllers.Data
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options):base(options)
        {

        }
        public DbSet<User> user { get; set; }
    }
}

﻿using System;
using System.Data.SqlClient;

namespace Adodemo
{
    internal class Crud1
    {
        static void Main(string[] args)
        {
            SqlConnection con;
            string connectionstring = @"Data Source=DESKTOP-RQHF8JH;Initial Catalog=Assignments;Integrated Security=True";
            con = new SqlConnection(connectionstring);
            con.Open();
            try
            {
                Console.WriteLine("Connecton Established successfully");
                string ans;
                do
                {
                    Console.WriteLine("select from the options \n1.creation \n2.retrivr \n3.update \n4.delete");
                    int choice = int.Parse(Console.ReadLine());
                    switch(choice)
                    {
                        case 1:

                            Console.WriteLine("Enter Emp Id:");
                            int EmpId=int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Emp Name:");
                            string EmpName=Console.ReadLine();
                            Console.WriteLine("Enter Emp Salary:");
                            int EmpSalary=int.Parse(Console.ReadLine());
                            string quree = "insert into Emp_data(Id, Empname, Empsalary) values(" + EmpId + ", '" + EmpName + "', " + EmpSalary + ");";
                            SqlCommand insertcommand = new SqlCommand(quree, con);
                            insertcommand.ExecuteNonQuery();
                            Console.WriteLine("data is inserted successfull");

                            break;
                        case 2:

                            Console.WriteLine("Employee data");
                            string D_quree = "select * from Emp_data; ";
                            SqlCommand displaycommand = new SqlCommand(D_quree, con);
                            SqlDataReader reader = displaycommand.ExecuteReader();
                            while (reader.Read())
                            {
                                Console.WriteLine("id: " + reader.GetValue(0).ToString());
                                Console.WriteLine("name: " + reader.GetValue(1).ToString());
                                Console.WriteLine("salary: " + reader.GetValue(2).ToString());

                            }
                            reader.Close();
                            break;

                        case 3:

                            Console.WriteLine("Enter Employee ID:");
                            int Emp_Id=int.Parse(Console.ReadLine());
                            //Console.WriteLine("Enter Employee Name:");
                            //string Emp_Name=Console.ReadLine();
                            Console.WriteLine("Enter Employee Salary:");
                            int Emp_Salary= int.Parse(Console.ReadLine());
                            string updateQuery = "UPDATE Emp_data SET Empsalary=" + Emp_Salary + " WHERE Id=" + Emp_Id + ";";
                            SqlCommand updatecommand = new SqlCommand(updateQuery, con);
                            updatecommand.ExecuteNonQuery();
                            Console.WriteLine("data updated sucessfully");
                            break;

                        case 4:
                            Console.WriteLine("Enter Employee Id:");
                            int Id= int.Parse(Console.ReadLine());
                            string deleteQuery = "DELETE FROM Emp_data WHERE Id="+Id+";";
                            SqlCommand deletecommand = new SqlCommand(deleteQuery, con);
                            deletecommand.ExecuteNonQuery();
                            Console.WriteLine("Deleted Successfully");
                            break;


                        default:
                            Console.WriteLine("wrong input");
                            break;
                    }
                    Console.WriteLine("do you want to continue");
                    ans = Console.ReadLine();
                }
                while (ans != "no");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        /*static void Main(string[] args)
        {
            string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
            //string quree = "create table Emp_data(Id Int,Empname nvarchar(40),Empsalary Int); ";
            //string quree = "insert into Emp_data(Id, Empname, Empsalary) values(101, 'Sai', 10000); ";
            //int Id=ReadLine()
            //string quree = "insert into Emp_data(Id, Empname, Empsalary) values(103, 'krish', 30000); ";
            //string quree = "UPDATE Emp_data SET Id=101, Empname='Sai' WHERE Empsalary=20000;";
            string quree = "select * from Emp_data; ";

            SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(quree, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(String.Format("{0}\t {1}", reader[0], reader[1]));
            }
            con.Close();
            //Console.WriteLine("table created");
            //Console.WriteLine("one row inserted");
            //Console.WriteLine("updated one row");
            Console.ReadLine();
        }*/

    }
}

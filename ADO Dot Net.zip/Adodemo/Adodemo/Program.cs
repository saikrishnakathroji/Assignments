﻿//creating the App.config to connect sql server
using System;
using System.Configuration;
using System.Data.SqlClient;
namespace Adodemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
            string quree = "select * from Customer";
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(quree, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(String.Format("{0}\t {1}", reader[0], reader[1]));
            }
            con.Close();
            Console.ReadLine();
        }
    }
}

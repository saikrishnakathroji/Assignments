﻿//with out setting System Configurations for sql
using System;
using System.Data.SqlClient;

namespace Adodemo
{
    internal class Program2
    {
        static void Main(string[] args)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection("Data Source=DESKTOP-RQHF8JH;Initial Catalog=Assignments;Integrated Security=True");
                conn.Open();
                Console.WriteLine("connected sucussfully");
            }
            catch (Exception ex)
            { Console.WriteLine(ex.Message); }
            conn.Close();
            Console.ReadLine();
        }
    }
}
